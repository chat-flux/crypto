import app from './src/app.mjs'
const PORT = 3000

app.listen(PORT, () => {
    console.log(`Server Api v1.0.1 rodando em http://localhost:${PORT}`);
  });